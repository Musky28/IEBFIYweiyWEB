package com.example.travelleradvisor.dto;

import java.util.ArrayList;
import java.util.List;

public class SunsetSunriseDTO {
   private String sunset;
   private String sunrise;
   public String coisas;

    public SunsetSunriseDTO()
    {

    }
    public void setSunset(String sunset){
        this.sunset=sunset;
    }
    public void setSunrise(String sunrise){
        this.sunrise=sunrise;
    }

    public String getSunset()
    {
        return sunset;
    }
    public String getSunrise()
    {
        return sunrise;
    }
}

