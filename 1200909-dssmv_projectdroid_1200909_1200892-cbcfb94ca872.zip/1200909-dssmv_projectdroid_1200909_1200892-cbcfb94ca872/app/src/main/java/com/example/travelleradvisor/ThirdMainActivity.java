package com.example.travelleradvisor;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.*;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.*;

import android.os.Bundle;

import androidx.fragment.app.FragmentActivity;

import com.example.travelleradvisor.model.SunsetSunrise;
import com.example.travelleradvisor.service.RequestService;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import com.example.travelleradvisor.helper.Utils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

public class ThirdMainActivity extends FragmentActivity implements OnMapReadyCallback{
    SunsetSunrise sunsetSunrise = null;
    EditText addressField;
    private GoogleMap mMap;
    private int limit = 10;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.secondactivity_main2);
        sunsetSunrise = new SunsetSunrise();

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);



    }
public void onClick(View v)
{
    String restaurant = "catering.restaurant",hotel = "hotel";


    switch (v.getId())
    {
        case R.id.Search:
            addressField = findViewById(R.id.Location);
            String address = addressField.getText().toString();

            List<Address> addressList = null;
            MarkerOptions userMarkerOptions = new MarkerOptions();

            if(!TextUtils.isEmpty(address))
            {
                Geocoder geocoder = new Geocoder(this);


                try
                {
                    addressList = geocoder.getFromLocationName(address, 1);

                    if(addressList != null)
                    {
                        for(int i =0;i<addressList.size();i++)
                        {
                            mMap.clear();
                            Address userAdress = addressList.get(i);
                            LatLng latLng = new LatLng(userAdress.getLatitude(),userAdress.getLongitude());

                            userMarkerOptions.position(latLng);
                            userMarkerOptions.title(address);
                            CameraPosition cameraPosition = new CameraPosition.Builder()
                                    .target(latLng )      // Sets the center of the map to Mountain View
                                    .zoom(17)                   // Sets the zoom
                                    .bearing(90)                // Sets the orientation of the camera to east
                                    .tilt(30)                   // Sets the tilt of the camera to 30 degrees
                                    .build();                   // Creates a CameraPosition from the builder
                            mMap.addMarker(userMarkerOptions.position(latLng).title(address));
                            mMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));


                        }
                    }else{
                        Toast.makeText(this,"Location not found ...", Toast.LENGTH_SHORT).show();
                    }
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
            else{
                Toast.makeText(this,"please write any location", Toast.LENGTH_SHORT).show();
            }
            break;
        case R.id.SunsetAndSunriseINFO:
            getSunsetSunriseInfo();
            break;


    }
}

    private void getSunsetSunriseInfo() {
        String searchString1 = addressField.getText().toString();

        Geocoder geocoder = new Geocoder(ThirdMainActivity.this);
        List<Address> list = new ArrayList<>();
        try {
            list = geocoder.getFromLocationName(searchString1, 1);
        } catch (IOException e) {
            Log.e(TAG, "geoLocate: IOException: " + e.getMessage());
        }

        if (list.size() > 0) {
            Address address = list.get(0);
            Log.d(TAG, "geoLocate: found a lat: " + address.getLatitude() + ",lng=" + address.getLongitude());
            double lat =  address.getLatitude();
            double lng = address.getLongitude();


            getSunsetSunrise(Utils.URL_SERVICE1 + "lat=" + lat + "&lng=" + lng);


        }
    }



    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        // Add a marker in Sydney and move the camera
        LatLng sydney = new LatLng(27.746974, 85.301582);
        MarkerOptions options = new MarkerOptions().position(sydney).title("Kathmandu, Nepal");
        CameraPosition cameraPosition = new CameraPosition.Builder()
                .target(sydney )      // Sets the center of the map to Mountain View
                .zoom(17)                   // Sets the zoom
                .bearing(90)                // Sets the orientation of the camera to east
                .tilt(30)                   // Sets the tilt of the camera to 30 degrees
                .build();                   // Creates a CameraPosition from the builder
        mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
        mMap.addMarker(options);
    }

    private void getSunsetSunrise(String urlStr)
    {
        new Thread(){
            public void run(){
                try {
                    sunsetSunrise = RequestService.getSunsetSunrise(urlStr);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (sunsetSunrise != null) {
                                createDialog();

                            }
                        }
                    });
                }catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
        }.start();

    }


    private void createDialog(){
        DisplayMetrics dn = new DisplayMetrics();
        final Dialog dialog = new Dialog(this,R.style.DialogStyle);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.WHITE));
        LayoutInflater inflater = (LayoutInflater) this.getSystemService(LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.list_sunsetsunrise,null);
        dialog.setContentView(view);
        dialog.show();
        dialog.getWindow().setLayout(1000,1200);
        TextView sunset= (TextView) view.findViewById(R.id.sunset);
        sunset.setText("Sunset:   " + sunsetSunrise.getSunset());


        TextView sunrise = (TextView)  view.findViewById(R.id.sunrise);
        sunrise.setText("Sunrise:  " + sunsetSunrise.getSunrise());

    }

    @Override
    protected void onPause(){
        super.onPause();
        Log.i("THIRDMAINACTIVITY","onPause");
    }
    @Override
    protected void onStop() {
        super.onStop();
        Log.i("THIRDMAINACTIVITY","onStop");
    }

}






