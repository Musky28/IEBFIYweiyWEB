package com.example.travelleradvisor.dto;

import com.example.travelleradvisor.model.SunsetSunrise;

import java.util.ArrayList;
import java.util.List;

public class Mapper {
    public static SunsetSunrise sunsetSunriseDTO2SunsetSunrise(SunsetSunriseDTO sunsetSunriseDTO) throws  NullPointerException{
        SunsetSunrise data = null;
        data = new SunsetSunrise(sunsetSunriseDTO.getSunrise(), sunsetSunriseDTO.getSunset());
        return data;
    }



}


