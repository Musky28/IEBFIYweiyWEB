package com.example.travelleradvisor.json;

import com.example.travelleradvisor.dto.SunsetSunriseDTO;
import org.json.JSONArray;
import org.json.JSONObject;


public class JsonHandler {
    public static SunsetSunriseDTO deSerializeJson2SunsetSunriseDTO(String resp) {
        SunsetSunriseDTO sunsetSunriseDTO = new SunsetSunriseDTO();
        try {
            JSONObject mResponseObject = new JSONObject(resp);
            String cod = mResponseObject.getJSONObject("results").getString("sunrise");
            if (!cod.isEmpty()) {
                sunsetSunriseDTO.setSunrise(mResponseObject.getJSONObject("results").getString("sunrise"));
                sunsetSunriseDTO.setSunset(mResponseObject.getJSONObject("results").getString("sunset"));
                return sunsetSunriseDTO;
            } else {
                return null;
            }

        } catch (Exception ee) {
            return null;
        }
    }

}






