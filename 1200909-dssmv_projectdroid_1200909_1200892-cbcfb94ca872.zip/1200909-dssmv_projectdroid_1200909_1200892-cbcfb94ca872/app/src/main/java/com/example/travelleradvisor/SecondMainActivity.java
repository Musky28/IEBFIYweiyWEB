package com.example.travelleradvisor;

import android.Manifest;
import android.app.Dialog;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import com.example.travelleradvisor.model.SunsetSunrise;
import com.example.travelleradvisor.service.RequestService;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.example.travelleradvisor.helper.Utils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

public class SecondMainActivity extends AppCompatActivity {
    private Button Restaurants;
    private Button SunsetSunrise;
    private SupportMapFragment supportMapFragment;
    private FusedLocationProviderClient client;
    private GoogleMap mMap;
    SunsetSunrise sunsetSunrise = null;
    double currentLat = 0, currentLong = 0;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.secondactivity_main);

        supportMapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        client = LocationServices.getFusedLocationProviderClient(SecondMainActivity.this);

        if (ActivityCompat.checkSelfPermission(SecondMainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            getCurrentLocation();
        } else {
            ActivityCompat.requestPermissions(SecondMainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 44);
        }

        SunsetSunrise = findViewById(R.id.SunsetAndSunriseINFO);
        SunsetSunrise.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSunsetSunriseInfo();

            }
        });
    }


    private void getCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        Task<Location> task = client.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if(location != null){
                    currentLat = location.getLatitude();
                    currentLong = location.getLongitude();

                }supportMapFragment.getMapAsync(new OnMapReadyCallback() {
                    @Override
                    public void onMapReady(GoogleMap googleMap) {
                        LatLng latLng = new LatLng(currentLat,currentLong);
                        MarkerOptions options = new MarkerOptions().position(latLng).title("I'm here");
                        CameraPosition cameraPosition = new CameraPosition.Builder()
                                .target(latLng )      // Sets the center of the map to Mountain View
                                .zoom(17)                   // Sets the zoom
                                .bearing(90)                // Sets the orientation of the camera to east
                                .tilt(30)                   // Sets the tilt of the camera to 30 degrees
                                .build();                   // Creates a CameraPosition from the builder
                        googleMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                        googleMap.addMarker(options);

                    }
                });
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==44){
            if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED){
                getCurrentLocation();
            }
        }
    }
    private void createDialog(){
        DisplayMetrics dn = new DisplayMetrics();
        final Dialog dialog = new Dialog(this,R.style.DialogStyle);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.WHITE));
        LayoutInflater inflater = (LayoutInflater) this.getSystemService(LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.list_sunsetsunrise,null);
        dialog.setContentView(view);
        dialog.show();
        dialog.getWindow().setLayout(1000,1200);
        TextView sunset= (TextView) view.findViewById(R.id.sunset);
        sunset.setText("Sunset:   " + sunsetSunrise.getSunset());

        TextView sunrise = (TextView)  view.findViewById(R.id.sunrise);
        sunrise.setText("Sunrise:  " + sunsetSunrise.getSunrise());




    }
    private void getSunsetSunrise(String urlStr)
    {
        new Thread(){
            public void run(){
                try {
                    sunsetSunrise = RequestService.getSunsetSunrise(urlStr);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (sunsetSunrise != null) {
                                createDialog();

                            }
                        }
                    });
                }catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
        }.start();

    }
    private void getSunsetSunriseInfo() {

            try{
                if(ActivityCompat.checkSelfPermission(SecondMainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)== PackageManager.PERMISSION_GRANTED){

                    final Task location = client.getLastLocation();
                    location.addOnCompleteListener(new OnCompleteListener() {
                        @Override
                        public void onComplete(@NonNull Task task) {
                            if(task.isSuccessful()){
                                Log.d(TAG, "onComplete: found location!");
                                Location currentLocation = (Location) task.getResult();
                                Geocoder geocoder = new Geocoder(SecondMainActivity.this);
                                List<Address> list = new ArrayList<>();
                                try {
                                    list = geocoder.getFromLocation(currentLocation.getLatitude(),currentLocation.getLongitude(),1);
                                } catch (IOException e) {
                                    Log.e(TAG, "geoLocate: IOException: " + e.getMessage());
                                }
                                if (list.size() > 0) {
                                    Address address = list.get(0);
                                    Log.d(TAG, "geoLocate: found a location: " + address.getLatitude() + "," + address.getLongitude());

                                    double lat = address.getLatitude();
                                    double lng = address.getLongitude();
                                    getSunsetSunrise(Utils.URL_SERVICE1 + "lat=" + lat + "&lng=" + lng);
                                }
                            }else{
                                Log.d(TAG, "onComplete: current location is null");
                                Toast.makeText(SecondMainActivity.this, "unable to get current location", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }catch (SecurityException e){
                Log.e(TAG, "getDeviceLocation: SecurityException: " + e.getMessage() );
            }


        }

}

