package com.example.travelleradvisor.service;

import com.example.travelleradvisor.dto.Mapper;
import com.example.travelleradvisor.dto.SunsetSunriseDTO;
import com.example.travelleradvisor.json.JsonHandler;
import com.example.travelleradvisor.model.SunsetSunrise;
import com.example.travelleradvisor.network.HttpOperation;

public class RequestService {
    private static SunsetSunriseDTO _getSunsetSunrise(String urlStr) {
        SunsetSunriseDTO location = null;
        try {
            String jsonString = HttpOperation.get(urlStr);
            location = JsonHandler.deSerializeJson2SunsetSunriseDTO(jsonString);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return location;
    }

    public static SunsetSunrise getSunsetSunrise(String urlStr) {
        SunsetSunriseDTO sunsetSunriseDTO = _getSunsetSunrise(urlStr);
        SunsetSunrise sunsetSunrise = Mapper.sunsetSunriseDTO2SunsetSunrise(sunsetSunriseDTO);
        return sunsetSunrise;

    }




}
