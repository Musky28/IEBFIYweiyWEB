package com.example.travelleradvisor.helper;

public class Utils {
       public static final String URL_SERVICE1 = "https://api.sunrise-sunset.org/json?";

}

