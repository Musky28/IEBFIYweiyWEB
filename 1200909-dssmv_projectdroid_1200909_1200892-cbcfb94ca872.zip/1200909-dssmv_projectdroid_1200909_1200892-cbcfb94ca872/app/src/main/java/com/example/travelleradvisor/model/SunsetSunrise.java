package com.example.travelleradvisor.model;

import java.util.Date;

public class SunsetSunrise {
    private String sunrise;
    private String sunset;

    public SunsetSunrise()
    {
    }
    public SunsetSunrise(String sunrise,String sunset )
    {
        this.sunrise = sunrise;
        this.sunset = sunset;
    }

    public String getSunrise()
    {
        return sunrise;
    }
    public String getSunset()
    {
        return sunset;
    }


}
